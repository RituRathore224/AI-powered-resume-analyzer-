import os
from dotenv import load_dotenv
from tavily import TavilyClient



load_dotenv()


api_key = os.getenv("TAVILY_API_KEY")


tavily_client = TavilyClient(api_key=api_key)


def search_job_role(job_role):

    query = f'"{job_role}" job opening job description requirements skills qualifications'

    response = tavily_client.search(
    query=query,
    search_depth="advanced",
    max_results=10
    )

    return response

def get_combined_job_description(job_results):

    combined_text = ""

    for result in job_results:

        title = result.get("title", "")
        content = result.get("content", "")

        combined_text += "\n"
        combined_text += "JOB TITLE: " + title + "\n"
        combined_text += content + "\n"
        combined_text += "-" * 80 + "\n"

    return combined_text

def get_job_results(job_role):

    results = search_job_role(job_role)

    job_results = []

    for result in results["results"]:

        title = result.get("title", "").lower()
        content = result.get("content", "").lower()

        keywords = [
            "job description",
            "responsibilities",
            "requirements",
            "qualifications",
            "skills",
            "experience"
        ]

        relevance_count = 0

        for keyword in keywords:

            if keyword in title or keyword in content:
                relevance_count += 1

        if relevance_count >= 2:
            job_results.append(result)

    return job_results

def remove_duplicate_jobs(job_results):

    unique_jobs = []
    seen_urls = set()

    for result in job_results:

        url = result.get("url", "")

        if url and url not in seen_urls:

            seen_urls.add(url)
            unique_jobs.append(result)

    return unique_jobs