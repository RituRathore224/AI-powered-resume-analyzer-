import re
import json
from pathlib import Path


# ============================================================
# LOAD SKILLS DATABASE
# ============================================================

def load_skills_database():

    file_path = Path(__file__).resolve().parent / "skills_database.json"

    with open(file_path, "r", encoding="utf-8") as file:

        skills_data = json.load(file)

    return skills_data


skills_database = load_skills_database()


# ============================================================
# MASTER SKILLS
# ============================================================

master_skills = []

for category in skills_database.values():

    if isinstance(category, list):

        master_skills.extend(category)


# Remove duplicates while preserving order
master_skills = list(
    dict.fromkeys(master_skills)
)


# ============================================================
# GENERIC / NON-SKILL WORD FILTER
# ============================================================

GENERIC_TERMS = {

    "algorithms",
    "algorithm",
    "skills",
    "skill",
    "experience",
    "education",
    "knowledge",
    "communication",
    "teamwork",
    "leadership",
    "problem solving",
    "responsibilities",
    "requirements",
    "analysis",
    "analytical",
    "ability",
    "understanding",
    "development",
    "management",
    "testing",
    "research",
    "projects",
    "project",
    "work",
    "business",
    "technology",
    "technologies",
    "tools",
    "software",
    "computer",
    "professional",
    "technical"
}


# ============================================================
# CLEAN JOB DESCRIPTION
# ============================================================

def clean_jd_text(jd_text):

    if not jd_text:

        return ""

    jd_text = jd_text.lower()

    jd_text = re.sub(
        r"\s+",
        " ",
        jd_text
    )

    return jd_text.strip()


# ============================================================
# EXTRACT SKILLS FROM ONE JOB DESCRIPTION
# ============================================================

def extract_jd_skills(jd_text, skills_list):

    jd_text = clean_jd_text(jd_text)

    found_skills = []

    if not jd_text:

        return found_skills

    for skill in skills_list:

        if not skill:
            continue

        skill_clean = skill.strip()

        if not skill_clean:
            continue

        # Ignore generic terms
        if skill_clean.lower() in GENERIC_TERMS:
            continue

        pattern = (
            r"(?<!\w)"
            + re.escape(skill_clean.lower())
            + r"(?!\w)"
        )

        if re.search(pattern, jd_text):

            found_skills.append(skill_clean)

    return found_skills


# ============================================================
# PARSE JOB DESCRIPTION
# ============================================================

def parse_job_description(jd_text, master_skills):

    skills = extract_jd_skills(
        jd_text,
        master_skills
    )

    return {
        "skills": skills
    }


# ============================================================
# SKILL FREQUENCY IN ONE JD
# ============================================================

def get_skill_frequency(jd_text, skills_list):

    jd_text = clean_jd_text(jd_text)

    skill_frequency = {}

    if not jd_text:

        return skill_frequency

    for skill in skills_list:

        if not skill:
            continue

        if skill.lower() in GENERIC_TERMS:
            continue

        pattern = (
            r"(?<!\w)"
            + re.escape(skill.lower())
            + r"(?!\w)"
        )

        matches = re.findall(
            pattern,
            jd_text
        )

        if matches:

            skill_frequency[skill] = len(matches)

    return skill_frequency


# ============================================================
# SKILL FREQUENCY ACROSS JOB POSTINGS
# ============================================================

def get_job_skill_frequency(job_results, skills_list):

    skill_frequency = {}

    if not job_results:

        return skill_frequency

    for skill in skills_list:

        if not skill:
            continue

        if skill.lower() in GENERIC_TERMS:
            continue

        count = 0

        pattern = (
            r"(?<!\w)"
            + re.escape(skill.lower())
            + r"(?!\w)"
        )

        for result in job_results:

            content = result.get(
                "content",
                ""
            )

            content = clean_jd_text(
                content
            )

            if re.search(
                pattern,
                content
            ):

                count += 1

        if count > 0:

            skill_frequency[skill] = count

    return skill_frequency


# ============================================================
# CATEGORIZE SKILLS
# ============================================================

def categorize_skills(
    skill_frequency,
    total_jobs
):

    core_skills = []
    additional_skills = []

    if total_jobs <= 0:

        return {
            "core_skills": [],
            "additional_skills": []
        }

    for skill, frequency in skill_frequency.items():

        # Ignore generic terms
        if skill.lower() in GENERIC_TERMS:
            continue

        frequency_ratio = (
            frequency / total_jobs
        )

        # Core skill:
        # Appears in at least 50% of jobs
        if frequency_ratio >= 0.50:

            core_skills.append(skill)

        # Additional skill:
        # Appears in at least 20% of jobs
        elif frequency_ratio >= 0.20:

            additional_skills.append(skill)

    # Most frequently required first
    core_skills.sort(
        key=lambda skill: skill_frequency[skill],
        reverse=True
    )

    additional_skills.sort(
        key=lambda skill: skill_frequency[skill],
        reverse=True
    )

    return {
        "core_skills": core_skills,
        "additional_skills": additional_skills
    }