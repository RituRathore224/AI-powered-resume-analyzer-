import re
def extract_languages(text):

    known_languages = [
        "english",
        "hindi",
        "french",
        "german",
        "spanish",
        "italian",
        "portuguese",
        "russian",
        "arabic",
        "chinese",
        "mandarin",
        "japanese",
        "korean",
        "tamil",
        "telugu",
        "marathi",
        "bengali",
        "gujarati",
        "punjabi",
        "kannada",
        "malayalam",
        "urdu",
        "nepali",
        "bhojpuri",
        "assamese",
        "odia",
        "sindhi"
    ]

    found_languages = []

    
    text = text.replace("\uf0b7", " ")

    lines = text.splitlines()

    inside_language_section = False

    for line in lines:

        line = line.strip()

        if not line:
            continue

        line_lower = line.lower()

       
        if re.search(
            r"\b(languages?|spoken languages?|languages known|language proficiency)\s*:",
            line_lower
        ):

            inside_language_section = True

            
            for language in known_languages:

                pattern = r"(?<!\w)" + re.escape(language) + r"(?!\w)"

                if re.search(pattern, line_lower):
                    found_languages.append(language.title())

            continue

        
        if inside_language_section:

            stop_words = [
                "skills",
                "technical skills",
                "experience",
                "work experience",
                "education",
                "projects",
                "certifications",
                "achievements",
                "summary",
                "objective",
                "contact"
            ]

            if any(
                re.search(r"\b" + re.escape(word) + r"\b", line_lower)
                for word in stop_words
            ):
                break

            
            for language in known_languages:

                pattern = r"(?<!\w)" + re.escape(language) + r"(?!\w)"

                if re.search(pattern, line_lower):
                    found_languages.append(language.title())

    return sorted(set(found_languages))
def extract_relocation(text):

    text_lower = text.lower()

    yes_patterns = [
        r"willing to relocate",
        r"open to relocation",
        r"open for relocation",
        r"ready to relocate",
        r"relocation\s*:\s*yes",
        r"relocate\s*:\s*yes"
    ]

    no_patterns = [
        r"not willing to relocate",
        r"not open to relocation",
        r"do not want to relocate",
        r"don't want to relocate",
        r"relocation\s*:\s*no",
        r"relocate\s*:\s*no"
    ]

    for pattern in no_patterns:
        if re.search(pattern, text_lower):
            return "No"

    for pattern in yes_patterns:
        if re.search(pattern, text_lower):
            return "Yes"

    return None
def extract_work_mode(text):

    text_lower = text.lower()

    remote_patterns = [
        r"work from home",
        r"work-from-home",
        r"\bwfh\b",
        r"remote work",
        r"remote job",
        r"remote position",
        r"fully remote"
    ]

    hybrid_patterns = [
        r"\bhybrid\b",
        r"hybrid work",
        r"hybrid job",
        r"hybrid position"
    ]

    onsite_patterns = [
        r"\bon[- ]?site\b",
        r"office based",
        r"office-based",
        r"work from office",
        r"fully onsite",
        r"fully on-site"
    ]

    if any(re.search(pattern, text_lower) for pattern in remote_patterns):
        return "Remote"

    if any(re.search(pattern, text_lower) for pattern in hybrid_patterns):
        return "Hybrid"

    if any(re.search(pattern, text_lower) for pattern in onsite_patterns):
        return "On-site"

    return None
def extract_notice_period(text):

    text_lower = text.lower()

    patterns = [
        r"notice period\s*[:\-]?\s*(\d+)\s*days?",
        r"notice period\s*[:\-]?\s*(\d+)\s*months?",
        r"(\d+)\s*days?\s*notice period",
        r"(\d+)\s*months?\s*notice period"
    ]

    for pattern in patterns:
        match = re.search(pattern, text_lower)

        if match:
            return match.group()

    immediate_patterns = [
        r"immediate joining",
        r"immediately available",
        r"available immediately",
        r"can join immediately"
    ]

    for pattern in immediate_patterns:
        if re.search(pattern, text_lower):
            return "Immediate"

    return None
def extract_availability(text):

    text_lower = text.lower()

    patterns = [
        r"available immediately",
        r"immediately available",
        r"immediate joining",
        r"can join immediately",
        r"available to join"
    ]

    for pattern in patterns:
        if re.search(pattern, text_lower):
            return "Immediate"

    return None