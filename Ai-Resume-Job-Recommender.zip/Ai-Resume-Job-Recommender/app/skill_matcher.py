import re


# ============================================================
# NORMALIZE SKILL
# ============================================================

def normalize_skill(skill):

    if not skill:
        return ""

    skill = skill.lower().strip()

    # Common variations
    replacements = {
        "scikit learn": "scikit-learn",
        "sklearn": "scikit-learn",
        "powerbi": "power bi",
        "ms excel": "excel",
        "microsoft excel": "excel",
        "postgres": "postgresql",
        "postgre sql": "postgresql",
        "nodejs": "node.js",
        "reactjs": "react",
        "javascript": "javascript",
        "js": "javascript",
        "typescript": "typescript",
        "ts": "typescript",
        "machine-learning": "machine learning",
        "deep-learning": "deep learning",
    }

    skill = replacements.get(skill, skill)

    # Remove unnecessary spaces
    skill = re.sub(r"\s+", " ", skill)

    return skill


# ============================================================
# PREPARE SKILLS
# ============================================================

def prepare_skills(skills):

    if not skills:
        return []

    normalized = []

    for skill in skills:

        skill = normalize_skill(skill)

        if skill and skill not in normalized:
            normalized.append(skill)

    return normalized


# ============================================================
# OVERALL SKILL MATCH
# ============================================================

def match_skills(resume_skills, job_skills):

    resume_skills = prepare_skills(resume_skills)
    job_skills = prepare_skills(job_skills)

    matched_skills = []
    missing_skills = []

    for skill in job_skills:

        if skill in resume_skills:

            matched_skills.append(skill)

        else:

            missing_skills.append(skill)

    if job_skills:

        match_score = (
            len(matched_skills) /
            len(job_skills)
        ) * 100

    else:

        match_score = 0

    return {
        "matched_skills": matched_skills,
        "missing_skills": missing_skills,
        "match_score": round(match_score, 2)
    }


# ============================================================
# CORE SKILL MATCH
# ============================================================

def match_core_skills(resume_skills, core_skills):

    resume_skills = prepare_skills(resume_skills)
    core_skills = prepare_skills(core_skills)

    matched_core_skills = []
    missing_core_skills = []

    for skill in core_skills:

        if skill in resume_skills:

            matched_core_skills.append(skill)

        else:

            missing_core_skills.append(skill)

    if core_skills:

        core_match_score = (
            len(matched_core_skills) /
            len(core_skills)
        ) * 100

    else:

        core_match_score = 0

    return {
        "matched_core_skills": matched_core_skills,
        "missing_core_skills": missing_core_skills,
        "core_match_score": round(core_match_score, 2)
    }