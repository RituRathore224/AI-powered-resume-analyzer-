def validate_resume_data(resume_data):

    required_fields = [
        "name",
        "email",
        "phone",
        "education",
        "skills",
        "experience",
        "projects",
        "additional_information"
    ]

    missing_fields = []

    for field in required_fields:

        if field not in resume_data:
            missing_fields.append(field)

    return missing_fields
def validate_resume(resume_data):

    required_fields = [
        "name",
        "email",
        "phone",
        "education",
        "skills",
        "experience",
        "projects",
        "additional_information"
    ]

    missing_fields = []

    for field in required_fields:
        if field not in resume_data or not resume_data[field]:
            missing_fields.append(field)

    return missing_fields