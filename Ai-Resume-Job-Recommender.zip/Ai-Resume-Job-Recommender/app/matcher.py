def calculate_skill_match(resume_data, jd_data):

    resume_skills = {
        skill.lower().strip()
        for skill in resume_data.get("skills", [])
    }

    jd_skills = {
        skill.lower().strip()
        for skill in jd_data.get("required_skills", [])
    }

    matched_skills = resume_skills.intersection(jd_skills)
    missing_skills = jd_skills - resume_skills

    if len(jd_skills) == 0:
        match_score = 0
    else:
        match_score = (
            len(matched_skills) / len(jd_skills)
        ) * 100

    return {
        "matched_skills": sorted(matched_skills),
        "missing_skills": sorted(missing_skills),
        "match_score": round(match_score, 2)
    }