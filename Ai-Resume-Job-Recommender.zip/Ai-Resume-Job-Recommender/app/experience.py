import re
def extract_experience(text):
    lines = text.splitlines()
    experience_section_keywords = [
        "work experience",
        "professional experience",
        "employment history",
        "work history",
        "career history"
    ]

    stop_section_keywords = [
        "professional summary",
        "summary",
        "profile",
        "career objective",
        "objective",
        "education",
        "academic qualification",
        "skills",
        "technical skills",
        "projects",
        "certifications",
        "achievements",
        "languages",
        "interests",
        "hobbies"
    ]
    experience = []
    inside_experience = False
    for line in lines:
        line = line.strip()
        if not line:
            continue

        line_lower = line.lower()
        if any(keyword in line_lower for keyword in experience_section_keywords):
            inside_experience = True
            continue
        if inside_experience and any(keyword in line_lower for keyword in stop_section_keywords):
            break
        if inside_experience:
            experience.append(line)
            
        
        return experience if experience else []

def extract_experience_dates(experience):
    if not experience:
        return []

    date_patterns = [
        r"\b(?:jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|"
        r"jun(?:e)?|jul(?:y)?|aug(?:ust)?|sep(?:tember)?|oct(?:ober)?|"
        r"nov(?:ember)?|dec(?:ember)?)\s+\d{4}\s*[-–—]\s*"
        r"(?:present|current|"
        r"(?:jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|"
        r"jun(?:e)?|jul(?:y)?|aug(?:ust)?|sep(?:tember)?|oct(?:ober)?|"
        r"nov(?:ember)?|dec(?:ember)?)\s+\d{4})\b",

        r"\b\d{4}\s*[-–—]\s*(?:\d{4}|present|current)\b",

        r"\b\d{1,2}/\d{4}\s*[-–—]\s*(?:\d{1,2}/\d{4}|present|current)\b"
    ]

    dates = []

    for line in experience:

        for pattern in date_patterns:

            matches = re.findall(
                pattern,
                line,
                flags=re.IGNORECASE
            )

            dates.extend(matches)

    return sorted(set(dates))

def is_date_line(line):

    date_patterns = [
        r"\b(?:jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|"
        r"jun(?:e)?|jul(?:y)?|aug(?:ust)?|sep(?:tember)?|oct(?:ober)?|"
        r"nov(?:ember)?|dec(?:ember)?)\s+\d{4}\b",

        r"\b\d{4}\s*[-–—]\s*(?:\d{4}|present|current)\b",

        r"\b\d{1,2}/\d{4}\b"
    ]

    for pattern in date_patterns:

        if re.search(pattern, line, flags=re.IGNORECASE):
            return True

    return False

def extract_job_details(experience):
    if not experience:
        return []

    job_title_keywords = [
        "intern",
        "analyst",
        "developer",
        "engineer",
        "scientist",
        "designer",
        "manager",
        "consultant",
        "specialist",
        "associate",
        "executive",
        "lead",
        "architect",
        "administrator",
        "researcher",
        "coordinator",
        "trainee"
    ]

    company_keywords = [
        "pvt",
        "private",
        "limited",
        "ltd",
        "llc",
        "inc",
        "corporation",
        "technologies",
        "technology",
        "solutions",
        "systems",
        "services",
        "labs",
        "group",
        "company"
    ]

    jobs = []

    current_job = {
        "job_title": None,
        "company": None,
        "duration": None,
        "responsibilities": []
    }

    for index, line in enumerate(experience):

        line = line.strip()

        if not line:
            continue

        
        if is_date_line(line):

            
            if (
                current_job["job_title"]
                or current_job["company"]
                or current_job["duration"]
                or current_job["responsibilities"]
            ):
                jobs.append(current_job)

            current_job = {
                "job_title": None,
                "company": None,
                "duration": line,
                "responsibilities": []
            }

            
            nearby_lines = experience[max(0, index - 2):index]

            for nearby_line in nearby_lines:

                nearby_line = nearby_line.strip()

                if not nearby_line:
                    continue

                nearby_lower = nearby_line.lower()

                
                if (
                    current_job["job_title"] is None
                    and any(
                        keyword in nearby_lower
                        for keyword in job_title_keywords
                    )
                ):
                    current_job["job_title"] = nearby_line
                    continue

                
                if (
                    current_job["company"] is None
                    and any(
                        keyword in nearby_lower
                        for keyword in company_keywords
                    )
                ):
                    current_job["company"] = nearby_line
                    continue

        else:

            
            if current_job["duration"] is not None:

                current_job["responsibilities"].append(line)

    
    if (
        current_job["job_title"]
        or current_job["company"]
        or current_job["duration"]
        or current_job["responsibilities"]
    ):
        jobs.append(current_job)

    return jobs

    
        
        