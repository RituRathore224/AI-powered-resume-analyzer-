
import streamlit as st
from backend import analyze_resume

# ============================================================
# PAGE CONFIG
# ============================================================

st.set_page_config(
    page_title="ResumeAI — Resume Analyzer",
    page_icon="✦",
    layout="wide",
    initial_sidebar_state="collapsed"
)


# ============================================================
# CUSTOM CSS
# ============================================================

st.markdown("""
<style>

@import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Space+Grotesk:wght@400;500;600;700&display=swap');


/* ============================================================
   GLOBAL
============================================================ */

.stApp {
    background:
        radial-gradient(
            circle at 15% 10%,
            rgba(99, 102, 241, 0.13),
            transparent 28%
        ),
        radial-gradient(
            circle at 85% 20%,
            rgba(139, 92, 246, 0.10),
            transparent 30%
        ),
        #080b14;

    color: #f8fafc;
    font-family: 'DM Sans', sans-serif;
}


.block-container {
    max-width: 1180px;
    padding-top: 2rem;
    padding-bottom: 4rem;
}


/* ============================================================
   HIDE STREAMLIT DEFAULTS
============================================================ */

#MainMenu {
    visibility: hidden;
}

footer {
    visibility: hidden;
}

header {
    visibility: hidden;
}


/* ============================================================
   NAVBAR
============================================================ */

.navbar-box {
    display: flex;
    align-items: center;
    justify-content: space-between;

    padding: 14px 20px;
    margin-bottom: 55px;

    border: 1px solid rgba(255,255,255,0.08);
    border-radius: 18px;

    background: rgba(15, 18, 30, 0.72);

    backdrop-filter: blur(18px);
}


.logo-text {
    font-family: 'Space Grotesk', sans-serif;
    font-size: 21px;
    font-weight: 700;

    color: #ffffff;
}


.logo-icon-box {
    display: inline-flex;
    align-items: center;
    justify-content: center;

    width: 34px;
    height: 34px;

    margin-right: 10px;

    border-radius: 10px;

    background: linear-gradient(
        135deg,
        #6366f1,
        #8b5cf6
    );

    box-shadow:
        0 0 25px rgba(99,102,241,0.35);

    color: white;
    font-size: 17px;
}


.status-text {
    display: flex;
    align-items: center;
    gap: 8px;

    color: #94a3b8;
    font-size: 13px;
}


.status-dot {
    width: 7px;
    height: 7px;

    border-radius: 50%;

    background: #22c55e;

    box-shadow:
        0 0 10px rgba(34,197,94,0.8);
}


/* ============================================================
   HERO
============================================================ */

.hero {
    text-align: center;
    margin-bottom: 48px;
}


.badge-box {
    display: inline-block;

    padding: 7px 13px;

    border: 1px solid rgba(139,92,246,0.28);
    border-radius: 999px;

    background: rgba(99,102,241,0.08);

    color: #c4b5fd;

    font-size: 12px;
    font-weight: 600;

    letter-spacing: 0.3px;
}


.hero-title {
    margin-top: 20px;
    margin-bottom: 14px;

    font-family: 'Space Grotesk', sans-serif;

    font-size: clamp(40px, 6vw, 68px);
    line-height: 1.02;

    letter-spacing: -2.5px;

    background: linear-gradient(
        100deg,
        #ffffff 15%,
        #c4b5fd 55%,
        #818cf8 90%
    );

    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
}


.hero-description {
    max-width: 620px;

    margin: auto;

    color: #94a3b8;

    font-size: 16px;
    line-height: 1.7;
}


/* ============================================================
   ANALYZER CARD
============================================================ */

.analyzer-card {
    padding: 34px;

    border: 1px solid rgba(255,255,255,0.08);

    border-radius: 26px;

    background:
        linear-gradient(
            145deg,
            rgba(20,24,40,0.94),
            rgba(12,15,26,0.94)
        );

    box-shadow:
        0 30px 80px rgba(0,0,0,0.35);

    margin-bottom: 28px;
}


.section-label {
    color: #f8fafc;

    font-family: 'Space Grotesk', sans-serif;

    font-size: 19px;
    font-weight: 600;

    margin-bottom: 5px;
}


.section-description {
    color: #64748b;

    font-size: 13px;

    margin-bottom: 22px;
}


/* ============================================================
   FILE UPLOADER
============================================================ */

[data-testid="stFileUploader"] {
    width: 100%;
}


[data-testid="stFileUploaderDropzone"] {
    min-height: 190px;

    border: 1.5px dashed rgba(129,140,248,0.45) !important;

    border-radius: 20px !important;

    background:
        radial-gradient(
            circle at center,
            rgba(99,102,241,0.08),
            rgba(10,13,23,0.55)
        ) !important;

    transition: all 0.25s ease;
}


[data-testid="stFileUploaderDropzone"]:hover {
    border-color: #818cf8 !important;

    background:
        rgba(99,102,241,0.09) !important;

    box-shadow:
        0 0 35px rgba(99,102,241,0.10);
}


[data-testid="stFileUploaderDropzone"] button {
    border-radius: 10px !important;

    background: rgba(99,102,241,0.15) !important;

    border: 1px solid rgba(129,140,248,0.25) !important;

    color: #c4b5fd !important;
}


/* ============================================================
   TEXT INPUT
============================================================ */

[data-testid="stTextInput"] input {

    height: 52px;

    border-radius: 14px !important;

    border: 1px solid rgba(255,255,255,0.10) !important;

    background: rgba(255,255,255,0.035) !important;

    color: #ffffff !important;

    font-size: 15px !important;

    transition: all 0.2s ease;
}


[data-testid="stTextInput"] input:focus {

    border-color: #818cf8 !important;

    box-shadow:
        0 0 0 3px rgba(99,102,241,0.12) !important;
}


/* ============================================================
   BUTTON
============================================================ */

.stButton > button {

    width: 100%;

    height: 52px;

    border: none !important;

    border-radius: 14px !important;

    background:
        linear-gradient(
            100deg,
            #6366f1,
            #8b5cf6
        ) !important;

    color: white !important;

    font-family: 'DM Sans', sans-serif !important;

    font-size: 15px !important;

    font-weight: 700 !important;

    box-shadow:
        0 12px 30px rgba(99,102,241,0.22);

    transition:
        transform 0.2s ease,
        box-shadow 0.2s ease;
}


.stButton > button:hover {

    transform: translateY(-2px);

    box-shadow:
        0 16px 40px rgba(99,102,241,0.32);
}


/* ============================================================
   FEATURE CARDS
============================================================ */

.feature-card {

    min-height: 220px;

    padding: 25px;

    border: 1px solid rgba(255,255,255,0.07);

    border-radius: 20px;

    background:
        rgba(15,18,30,0.70);

    transition:
        transform 0.25s ease,
        border-color 0.25s ease;
}


.feature-card:hover {

    transform: translateY(-4px);

    border-color:
        rgba(129,140,248,0.30);
}


.feature-icon {

    font-size: 25px;

    margin-bottom: 15px;
}


.feature-title {

    font-family: 'Space Grotesk', sans-serif;

    font-size: 17px;

    font-weight: 600;

    margin-bottom: 8px;

    color: #ffffff;
}


.feature-text {

    color: #64748b;

    font-size: 13px;

    line-height: 1.6;
}

/* ============================================================
   RESUME STRENGTH CARDS
============================================================ */

.strength-card {
    min-height: 115px;
    padding: 20px 22px;

    border: 1px solid rgba(34,197,94,0.16);
    border-radius: 18px;

    background:
        linear-gradient(
            145deg,
            rgba(20,30,28,0.90),
            rgba(12,18,20,0.90)
        );

    margin-bottom: 14px;

    transition:
        transform 0.2s ease,
        border-color 0.2s ease;
}

.strength-card:hover {
    transform: translateY(-3px);

    border-color:
        rgba(34,197,94,0.35);
}


.strength-icon {
    display: inline-flex;

    align-items: center;
    justify-content: center;

    width: 32px;
    height: 32px;

    margin-bottom: 10px;

    border-radius: 10px;

    background: rgba(34,197,94,0.10);

    color: #4ade80;

    font-size: 15px;
}


.strength-title {
    color: #f8fafc;

    font-family: 'Space Grotesk', sans-serif;

    font-size: 15px;

    font-weight: 600;

    line-height: 1.4;
}


/* ============================================================
   CAREER RECOMMENDATION CARDS
============================================================ */

.recommendation-card {
    min-height: 145px;

    padding: 22px;

    border: 1px solid rgba(129,140,248,0.16);

    border-radius: 18px;

    background:
        linear-gradient(
            145deg,
            rgba(25,27,48,0.92),
            rgba(14,17,31,0.92)
        );

    margin-bottom: 14px;

    transition:
        transform 0.2s ease,
        border-color 0.2s ease;
}

.recommendation-card:hover {
    transform: translateY(-3px);

    border-color:
        rgba(129,140,248,0.38);
}


.recommendation-icon {
    display: inline-flex;

    align-items: center;
    justify-content: center;

    width: 34px;
    height: 34px;

    margin-bottom: 12px;

    border-radius: 10px;

    background: rgba(99,102,241,0.12);

    color: #a5b4fc;

    font-size: 16px;
}


.recommendation-title {
    color: #ffffff;

    font-family: 'Space Grotesk', sans-serif;

    font-size: 16px;

    font-weight: 600;

    margin-bottom: 7px;
}


.recommendation-text {
    color: #94a3b8;

    font-size: 13px;

    line-height: 1.65;
}

/* ============================================================
   FOOTER
============================================================ */

.footer {

    text-align: center;

    margin-top: 65px;

    color: #475569;

    font-size: 12px;
}

</style>
""", unsafe_allow_html=True)


# ============================================================
# NAVBAR
# ============================================================

navbar_left, navbar_right = st.columns([1, 1])


with navbar_left:

    st.markdown("### ✦ ResumeAI")


with navbar_right:

    st.markdown("🟢 AI Analysis Ready")


# ============================================================
# HERO
# ============================================================

st.markdown("### ✦ AI-POWERED RESUME ANALYSIS")

st.markdown(
    "# Your resume.  \n# Smarter career insights."
)

st.write(
    "Upload your resume, enter the role you're targeting, "
    "and discover how your skills match real-world job requirements."
)


# ============================================================
# ANALYZER CARD HEADER
# ============================================================

st.markdown("### 🚀 Start your analysis")

st.write(
    "Upload your latest resume and tell us what role you're targeting."
)


# ============================================================
# INPUT AREA
# ============================================================

left, right = st.columns(
    [1.15, 0.85],
    gap="large"
)


with left:

    st.markdown(
        '<div class="section-label">📄 Resume</div>',
        unsafe_allow_html=True
    )

    st.markdown(
        '<div class="section-description">'
        'PDF format • Your resume stays within the analysis flow'
        '</div>',
        unsafe_allow_html=True
    )

    uploaded_resume = st.file_uploader(
        "Upload PDF",
        type=["pdf"],
        label_visibility="collapsed"
    )


with right:

    st.markdown(
        '<div class="section-label">🎯 Target role</div>',
        unsafe_allow_html=True
    )

    st.markdown(
        '<div class="section-description">'
        'Enter the position you want to apply for'
        '</div>',
        unsafe_allow_html=True
    )

    job_role = st.text_input(
        "Job Role",
        placeholder="e.g. Data Scientist",
        label_visibility="collapsed"
    )

    st.markdown("<br>", unsafe_allow_html=True)

    analyze = st.button(
        "✦  Analyze My Resume",
        use_container_width=True
    )


# ============================================================
# BACKEND ANALYSIS
# ============================================================

if analyze:

    if uploaded_resume is None:

        st.error(
            "Please upload your resume before starting the analysis."
        )

    elif not job_role.strip():

        st.error(
            "Please enter the job role you want to analyze."
        )

    else:

        import os

        os.makedirs(
            "uploads",
            exist_ok=True
        )

        pdf_path = os.path.join(
            "uploads",
            "resume.pdf"
        )

        with open(
            pdf_path,
            "wb"
        ) as file:

            file.write(
                uploaded_resume.getbuffer()
            )

        try:

            with st.spinner(
                "AI is analyzing your resume..."
            ):

                result = analyze_resume(
                    pdf_path,
                    job_role.strip()
                )

            st.session_state["analysis_result"] = result

            st.success(
                "Resume analysis completed successfully!"
            )

        except Exception as e:

            st.error(
                f"Analysis failed: {e}"
            )


# ============================================================
# FEATURES HEADER
# ============================================================

st.markdown(
    "<br><br><br>",
    unsafe_allow_html=True
)

st.markdown("### ✦ WHAT YOU'LL GET")

st.markdown("## More than just a match score.")

st.write(
    "Understand your resume, target role and skill gaps."
)


# ============================================================
# FEATURE CARDS
# ============================================================

col1, col2, col3 = st.columns(
    3,
    gap="medium"
)


with col1:

    st.markdown("### ⌁ Resume Intelligence")

    st.write(
        "Extract education, degrees, skills, experience, "
        "projects and other important resume information."
    )


with col2:

    st.markdown("### ◎ Real Job Insights")

    st.write(
        "Analyze skills found across relevant job postings "
        "for the role you're targeting."
    )


with col3:

    st.markdown("### ↗ Skill Gap Analysis")

    st.write(
        "See matched skills, missing skills, core skills "
        "and your overall job-role match."
    )



# ============================================================
# FOOTER
# ============================================================

st.markdown(
    """
    <div class="footer">
        ResumeAI · AI Resume Analyzer & Job Matcher
    </div>
    """,
    unsafe_allow_html=True
)

# ============================================================
# ANALYSIS RESULT DASHBOARD
# ============================================================

if "analysis_result" in st.session_state:

    result = st.session_state["analysis_result"]

    st.markdown("---")
    st.markdown("## ✦ Resume Analysis Report")

    # --------------------------------------------------------
    # BASIC INFO
    # --------------------------------------------------------

    resume = result.get("resume", {})

    st.markdown("### 👤 Resume Information")

    col1, col2, col3 = st.columns(3)

    with col1:
        st.markdown("**Name**")
        st.write(resume.get("name") or "Not detected")

    with col2:
        st.markdown("**Email**")
        st.write(resume.get("email") or "Not detected")

    with col3:
        st.markdown("**Phone**")
        st.write(resume.get("phone") or "Not detected")

    col1, col2 = st.columns(2)

    with col1:
        st.markdown("**Education**")

    education = resume.get("education")

    if isinstance(education, list):

        for item in education:

            if isinstance(item, dict):

                for key, value in item.items():

                    if value:
                        st.write(
                            f"**{key.replace('_', ' ').title()}:** {value}"
                        )

            else:
                st.write(f"• {item}")

    elif isinstance(education, dict):

        for key, value in education.items():

            if value:
                st.write(
                    f"**{key.replace('_', ' ').title()}:** {value}"
                )

    elif education:

        st.write(education)

    else:

        st.write("Not detected")

    with col2:
        st.markdown("**Degree(s)**")
        degrees = resume.get("degrees", [])
        st.write(", ".join(degrees) if degrees else "Not detected")

    # --------------------------------------------------------
    # JOB ROLE
    # --------------------------------------------------------

    st.markdown("### 🎯 Target Job Role")

    st.info(result.get("job_role", "Not specified"))

    # --------------------------------------------------------
    # MATCH SCORES
    # --------------------------------------------------------

    st.markdown("### 📊 Skill Match")

    overall_score = result.get("overall_match_score", 0)
    core_score = result.get("core_match_score", 0)

    col1, col2 = st.columns(2)

    with col1:

        st.markdown("**Overall Match**")

        st.metric(
            "Resume vs Job Requirements",
            f"{overall_score}%"
        )

        st.progress(
            min(max(overall_score / 100, 0.0), 1.0)
        )


    with col2:

        st.markdown("**Core Skills Match**")

        st.metric(
            "Resume vs Core Skills",
            f"{core_score}%"
        )

        st.progress(
            min(max(core_score / 100, 0.0), 1.0)
        )

    # --------------------------------------------------------
    # MATCHED SKILLS
    # --------------------------------------------------------

    st.markdown("### ✅ Matched Skills")

    matched_skills = result.get("matched_skills", [])

    if matched_skills:

        cols = st.columns(4)

        for i, skill in enumerate(matched_skills):

            with cols[i % 4]:
                st.success(f"✓ {skill}")

    else:

        st.warning("No matching skills found.")

    # --------------------------------------------------------
    # MISSING SKILLS
    # --------------------------------------------------------

    st.markdown("### ❌ Missing Skills")

    missing_skills = result.get("missing_skills", [])

    if missing_skills:

        cols = st.columns(4)

        for i, skill in enumerate(missing_skills):

            with cols[i % 4]:
                st.error(f"✗ {skill}")

    else:

        st.success("No major missing skills detected.")
    # --------------------------------------------------------
    # CORE SKILLS
    # --------------------------------------------------------

    st.markdown("### ⭐ Core Skills Required")

    core_skills = result.get("core_skills", [])

    if core_skills:

        cols = st.columns(4)

        for i, skill in enumerate(core_skills):

            with cols[i % 4]:
                st.info(f"★ {skill}")

    else:

        st.write("No core skills detected.")

    # --------------------------------------------------------
    # ADDITIONAL SKILLS
    # --------------------------------------------------------

    st.markdown("### 📚 Additional Skills")

    additional_skills = result.get("additional_skills", [])

    if additional_skills:

        cols = st.columns(4)

        for i, skill in enumerate(additional_skills):

            with cols[i % 4]:
                st.write(f"• {skill}")

    else:

        st.write("No additional skills detected.")

    # ============================================================
    # RESUME STRENGTHS
    # ============================================================

    st.markdown("### 💪 Resume Strengths")

    st.caption(
        "Key strengths identified from your resume for the target role."
    )

    resume_strengths = result.get(
        "resume_strengths",
        []
    )

    if resume_strengths:

        cols = st.columns(2)

        for i, strength in enumerate(resume_strengths):

            with cols[i % 2]:

                st.success(
                    f"✓ {strength}"
                )

    else:

        st.info(
            "No specific resume strengths detected."
        )


    # ============================================================
    # CAREER RECOMMENDATIONS
    # ============================================================

    st.markdown("### 🎯 Career Recommendations")

    st.caption(
        "Practical suggestions based on your resume, skills and target role."
    )

    career_recommendations = result.get(
        "career_recommendations",
        []
    )

    if career_recommendations:

        for recommendation in career_recommendations:

            if isinstance(recommendation, dict):

                title = recommendation.get(
                    "title",
                    "Career Recommendation"
                )

                description = recommendation.get(
                    "description",
                    ""
                )

                with st.container(border=True):

                    st.markdown(
                        f"#### 💡 {title}"
                    )

                    st.write(
                        description
                    )

            else:

                with st.container(border=True):

                    st.write(
                        f"💡 {recommendation}"
                    )

    else:

        st.info(
            "No specific career recommendations generated."
        )
    # --------------------------------------------------------
    # SKILL GAP ANALYSIS
    # --------------------------------------------------------

    st.markdown("### 🧠 Skill Gap Analysis")

    missing_skills = result.get("missing_skills", [])
    core_skills = result.get("core_skills", [])

    if missing_skills:

        st.markdown(
            "These skills are present in the job requirements "
            "but were not detected in your resume."
        )

        for skill in missing_skills:

            if skill in core_skills:

                priority = "🔴 High Priority"
                action = "Core requirement — consider learning this first."

            else:

                priority = "🟡 Medium Priority"
                action = "Useful for the role — consider adding it to your skill set."

            col1, col2 = st.columns([2, 4])

            with col1:
                st.markdown(f"**{skill}**")
                st.write(priority)

            with col2:
                st.write(action)

            st.markdown("---")

    else:

        st.success(
            "No significant skill gaps detected for this job role."
        )
    # --------------------------------------------------------
    # EXPERIENCE
    # --------------------------------------------------------

    st.markdown("### 💼 Experience")

    experience = resume.get("experience")

    if experience:

        if isinstance(experience, list):

            for exp in experience:

                if isinstance(exp, dict):

                    job_title = exp.get(
                        "job_title",
                        exp.get("title", "Experience")
                    )

                    company = exp.get(
                        "company",
                        ""
                    )

                    duration = exp.get(
                        "duration",
                        ""
                    )

                    description = exp.get(
                        "description",
                        ""
                    )

                    st.markdown(
                        f"#### 💼 {job_title}"
                    )

                    if company:
                        st.write(
                            f"**Company:** {company}"
                        )

                    if duration:
                        st.write(
                            f"**Duration:** {duration}"
                        )

                    if description:

                        st.markdown("**Description:**")

                        if isinstance(description, list):

                            for item in description:
                                st.write(f"• {item}")

                        else:

                            st.write(description)

                    st.markdown("---")

                else:

                    st.write(f"• {exp}")

        elif isinstance(experience, dict):

            for key, value in experience.items():

                if value:
                    st.write(
                        f"**{key.replace('_', ' ').title()}:** {value}"
                    )

        else:

            st.write(experience)

    else:

        st.write("No experience detected.")

    # --------------------------------------------------------
    # PROJECTS
    # --------------------------------------------------------

    st.markdown("### 🚀 Projects")

    projects = resume.get("projects", [])

    if projects:

        for project in projects:

            if isinstance(project, dict):

                project_name = project.get(
                    "project_name",
                    "Unnamed Project"
                )

                technologies = project.get(
                    "technologies",
                    []
                )

                descriptions = project.get(
                    "description",
                    []
                )

                st.markdown(
                    f"#### 📌 {project_name}"
                )

            # -----------------------------
            # TECHNOLOGIES
            # -----------------------------

                if technologies:

                    st.markdown("**Technologies:**")

                    if isinstance(technologies, list):

                        st.write(
                            " • ".join(
                                str(tech)
                                for tech in technologies
                            )
                        )

                    else:

                        st.write(str(technologies))

            # -----------------------------
            # DESCRIPTION
            # -----------------------------

                if descriptions:

                    st.markdown("**Description:**")

                    if isinstance(descriptions, list):

                        for description in descriptions:

                            st.write(
                                f"• {description}"
                            )

                    else:

                        st.write(str(descriptions))

                st.markdown("---")

            else:

                st.write(f"• {project}")

    else:

        st.write("No projects detected.")

    # --------------------------------------------------------
    # ADDITIONAL INFORMATION
    # --------------------------------------------------------

    st.markdown("### ℹ️ Additional Information")

    additional_info = resume.get("additional_information", {})

    if additional_info:

        col1, col2, col3 = st.columns(3)

        with col1:
            st.markdown("**Languages**")

            languages = additional_info.get("languages")

            if isinstance(languages, list):

                for language in languages:
                    st.write(f"• {language}")

            elif isinstance(languages, dict):

                for language, level in languages.items():

                    st.write(
                        f"• **{language}:** {level}"
                    )

            elif languages:

                st.write(languages)

            else:

                st.write("Not detected")

        with col2:
            st.markdown("**Relocation**")
            st.write(
                additional_info.get("relocation")
                or "Not detected"
            )

        with col3:
            st.markdown("**Work Mode**")
            st.write(
                additional_info.get("work_mode")
                or "Not detected"
            )

    # --------------------------------------------------------
    # JOB SOURCES
    # --------------------------------------------------------

    st.markdown("### 💼 Jobs Analyzed")

    job_sources = result.get("job_sources", [])

    if job_sources:

        for job in job_sources:

            title = job.get("title", "Job")
            url = job.get("url", "")

            if url:
                st.markdown(
                    f"🔹 [{title}]({url})"
                )
            else:
                st.write(f"🔹 {title}")

    else:
        st.warning("No job sources found.")