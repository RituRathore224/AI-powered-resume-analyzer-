import re

def extract_certifications(text):
    lines = text.split("\n")
    
    certifications = []
    in_certifications = False

    for line in lines:
        line = line.strip()

        if not line:
            continue

        
        if re.search(r'\b(certifications?|certificates?)\b', line, re.IGNORECASE):
            in_certifications = True
            continue

        
        if in_certifications and re.search(
            r'\b(projects?|education|experience|skills?|technical skills?|languages?|achievements?|interests?|hobbies?)\b',
            line,
            re.IGNORECASE
        ):
            break

        if in_certifications:
            certifications.append(line)

    return certifications