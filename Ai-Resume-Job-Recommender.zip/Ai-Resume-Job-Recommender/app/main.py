from web_job_parser import (
    get_combined_job_description,
    get_job_results,
    remove_duplicate_jobs
)
from jd_parser import (
    parse_job_description,
    master_skills,
    get_skill_frequency,
    get_job_skill_frequency,
    categorize_skills
)
import re
from pdf_parser import extract_text_from_pdf
from extractor import extract_email, extract_phone,extract_name,extract_education
from skills import extract_skills
from additional_info import(extract_languages,extract_availability,extract_notice_period,extract_relocation,extract_work_mode)
from experience import (extract_experience,extract_experience_dates,extract_job_details)
from projects import (extract_projects,extract_project_details)
from validater import validate_resume_data,validate_resume
from skill_matcher import match_skills, match_core_skills
import json
def detect_degree(education_text):

    # Education agar list hai to usko string me convert karo
    if isinstance(education_text, list):
        education_text = " ".join(education_text)

    # Agar None hai
    if education_text is None:
        education_text = ""

    education_lower = education_text.lower()

    degree_patterns = {
        "B.Tech": r"\bb\.?\s*tech\b|\bbachelor\s+of\s+technology\b",
        "B.E": r"\bb\.?\s*e\.?\b|\bbachelor\s+of\s+engineering\b",
        "BCA": r"\bb\.?\s*c\.?\s*a\.?\b|\bbachelor\s+of\s+computer\s+applications\b",
        "MCA": r"\bm\.?\s*c\.?\s*a\.?\b|\bmaster\s+of\s+computer\s+applications\b",
        "BBA": r"\bb\.?\s*b\.?\s*a\.?\b|\bbachelor\s+of\s+business\s+administration\b",
        "MBA": r"\bm\.?\s*b\.?\s*a\.?\b|\bmaster\s+of\s+business\s+administration\b",
        "B.Sc": r"\bb\.?\s*sc\.?\b|\bbachelor\s+of\s+science\b",
        "M.Sc": r"\bm\.?\s*sc\.?\b|\bmaster\s+of\s+science\b",
        "B.Com": r"\bb\.?\s*com\.?\b|\bbachelor\s+of\s+commerce\b",
        "M.Com": r"\bm\.?\s*com\.?\b|\bmaster\s+of\s+commerce\b",
        "BA": r"\bb\.?\s*a\.?\b|\bbachelor\s+of\s+arts\b",
        "MA": r"\bm\.?\s*a\.?\b|\bmaster\s+of\s+arts\b",
        "B.Ed": r"\bb\.?\s*ed\.?\b|\bbachelor\s+of\s+education\b",
        "M.Ed": r"\bm\.?\s*ed\.?\b|\bmaster\s+of\s+education\b",
        "PhD": r"\bph\.?\s*d\.?\b|\bdoctor\s+of\s+philosophy\b",
        "Diploma": r"\bdiploma\b"
    }

    found_degrees = []

    for degree, pattern in degree_patterns.items():

        if re.search(pattern, education_lower):
            found_degrees.append(degree)

    return found_degrees

pdf_path = "uploads/resume.pdf"

text = extract_text_from_pdf(pdf_path)
project_lines = extract_projects(text)
project_details = extract_project_details(project_lines)
name = extract_name(text)
email = extract_email(text)
phone = extract_phone(text)
skills = extract_skills(text)
education = extract_education(text)
language = extract_languages(text)
availability = extract_availability(text)
notice_period = extract_notice_period(text)
relocation = extract_relocation(text)
work_mode = extract_work_mode(text)
experience = extract_experience(text)
experience_dates = extract_experience_dates(experience)
job_details = extract_job_details(experience)


additional_information = {
    "languages":language,
    "availability":availability,
    "notice_period":notice_period,
    "relocation":relocation,
    "work_mode":work_mode,

}
degrees = detect_degree(education)

resume_data ={
    "name":name,
    "email":email,
    "phone":phone,
    "skills":skills,
    "education":education,
    "degrees": degrees,
    "additional_information":additional_information,
    "experience": experience,
    "experience_dates": experience_dates,
    "job_details":job_details,
    "projects":project_details,
}
print("\n===== RESUME INFORMATION =====")

print("\nName:", resume_data["name"])
print("Email:", resume_data["email"])
print("Phone:", resume_data["phone"])

print("\nEducation:")
for education in resume_data["education"]:
    print("-", education)

print("\nDegrees:")
for degree in resume_data["degrees"]:
    print("-", degree)


print("\nSkills:")
for skill in resume_data["skills"]:
    print("-", skill)


missing_fields = validate_resume_data(resume_data)
missing_fields = validate_resume(resume_data)


print("\nMissing Fields:")

if missing_fields:
    for field in missing_fields:
        print("-", field)
else:
    print("All required fields are present!")
    print("\n===== JOB SEARCH =====")

job_role = input("Enter Job Role: ")

print("\nSearching for relevant jobs...")

job_results = get_job_results(job_role)

job_results = remove_duplicate_jobs(job_results)

job_description = get_combined_job_description(job_results)

print("\n===== JOB SOURCES =====")

for result in job_results:

    print("\nTitle:", result.get("title", "Unknown"))
    print("URL:", result.get("url", "Unknown"))

print("\nJob descriptions collected successfully!")

jd_data = parse_job_description(
    job_description,
    master_skills
)

skill_frequency = get_job_skill_frequency(
    job_results,
    master_skills
)

print("\n===== SKILL FREQUENCY ACROSS JOBS =====")

for skill, frequency in skill_frequency.items():

    print(
        "-",
        skill,
        ":",
        frequency,
        "out of",
        len(job_results),
        "jobs"
    )

skill_categories = categorize_skills(
    skill_frequency,
    len(job_results)
)

required_skills = []

total_jobs = len(job_results)

for skill, frequency in skill_frequency.items():

    if frequency >= (total_jobs * 0.2):

        required_skills.append(skill)

required_skills.sort(
    key=lambda skill: skill_frequency[skill],
    reverse=True
)


print("\n===== REQUIRED JOB SKILLS =====")

for skill in required_skills:

    print("-", skill)

print("\n===== CORE SKILLS =====")

for skill in skill_categories["core_skills"]:
    print("-", skill)


print("\n===== ADDITIONAL SKILLS =====")

for skill in skill_categories["additional_skills"]:
    print("-", skill)

match_result = match_skills(

    resume_data["skills"],

    required_skills

)

print("\n===== SKILL MATCHING =====")

print("\nMatched Skills:")

for skill in match_result["matched_skills"]:
    print("-", skill)

print("\nMissing Skills:")

for skill in match_result["missing_skills"]:
    print("-", skill)

print("\nMatch Score:", match_result["match_score"], "%")
core_match_result = match_core_skills(
    resume_data["skills"],
    skill_categories["core_skills"]
)

print("\n===== CORE SKILL MATCHING =====")

print("\nMatched Core Skills:")

for skill in core_match_result["matched_core_skills"]:
    print("-", skill)


print("\nMissing Core Skills:")

for skill in core_match_result["missing_core_skills"]:
    print("-", skill)


print(
    "\nCore Skill Match Score:",
    core_match_result["core_match_score"],
    "%"
)

print("\n")
print("=" * 60)
print("           AI RESUME ANALYZER REPORT")
print("=" * 60)

print("\nJob Role:", job_role)

print("\n--- MATCH SUMMARY ---")
print("Overall Match Score:", match_result["match_score"], "%")
print("Core Skill Match Score:", core_match_result["core_match_score"], "%")

print("\n--- MATCHED SKILLS ---")

if match_result["matched_skills"]:

    for skill in match_result["matched_skills"]:
        print("✓", skill)

else:
    print("No matched skills found.")


print("\n--- MISSING SKILLS ---")

if match_result["missing_skills"]:

    for skill in match_result["missing_skills"]:
        print("✗", skill)

else:
    print("No missing skills.")


print("\n--- CORE SKILLS ---")

if skill_categories["core_skills"]:

    for skill in skill_categories["core_skills"]:
        print("•", skill)

else:
    print("No core skills identified.")


print("\n--- ADDITIONAL SKILLS ---")

if skill_categories["additional_skills"]:

    for skill in skill_categories["additional_skills"]:
        print("•", skill)

else:
    print("No additional skills identified.")


print("\n" + "=" * 60)
print("                 END OF REPORT")
print("=" * 60)

final_report = {
    "job_role": job_role,

    "job_sources": [
        {
            "title": result.get("title", ""),
            "url": result.get("url", "")
        }
        for result in job_results
    ],

    "required_skills": jd_data["skills"],

    "skill_frequency": skill_frequency,

    "core_skills": skill_categories["core_skills"],

    "additional_skills": skill_categories["additional_skills"],

    "matched_skills": match_result["matched_skills"],

    "missing_skills": match_result["missing_skills"],

    "overall_match_score": match_result["match_score"],

    "matched_core_skills": core_match_result["matched_core_skills"],

    "missing_core_skills": core_match_result["missing_core_skills"],

    "core_match_score": core_match_result["core_match_score"]
}


with open("final_report.json", "w", encoding="utf-8") as file:

    json.dump(
        final_report,
        file,
        indent=4
    )


print("\nReport saved to final_report.json")



