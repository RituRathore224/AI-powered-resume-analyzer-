import re
import json

from pdf_parser import extract_text_from_pdf

from extractor import (
    extract_email,
    extract_phone,
    extract_name,
    extract_education
)

from skills import extract_skills

from additional_info import (
    extract_languages,
    extract_availability,
    extract_notice_period,
    extract_relocation,
    extract_work_mode
)

from experience import (
    extract_experience,
    extract_experience_dates,
    extract_job_details
)

from projects import (
    extract_projects,
    extract_project_details
)

from validater import (
    validate_resume_data,
    validate_resume
)

from skill_matcher import (
    match_skills,
    match_core_skills
)

from web_job_parser import (
    get_combined_job_description,
    get_job_results,
    remove_duplicate_jobs
)

from jd_parser import (
    parse_job_description,
    master_skills,
    get_job_skill_frequency,
    categorize_skills
)


# ============================================================
# DEGREE DETECTION
# ============================================================

def detect_degree(education_text):

    if isinstance(education_text, list):
        education_text = " ".join(education_text)

    if education_text is None:
        education_text = ""

    education_lower = education_text.lower()

    degree_patterns = {

        "B.Tech":
            r"\bb\.?\s*tech\b|\bbachelor\s+of\s+technology\b",

        "B.E":
            r"\bb\.?\s*e\.?\b|\bbachelor\s+of\s+engineering\b",

        "BCA":
            r"\bb\.?\s*c\.?\s*a\.?\b|\bbachelor\s+of\s+computer\s+applications\b",

        "MCA":
            r"\bm\.?\s*c\.?\s*a\.?\b|\bmaster\s+of\s+computer\s+applications\b",

        "BBA":
            r"\bb\.?\s*b\.?\s*a\.?\b|\bbachelor\s+of\s+business\s+administration\b",

        "MBA":
            r"\bm\.?\s*b\.?\s*a\.?\b|\bmaster\s+of\s+business\s+administration\b",

        "B.Sc":
            r"\bb\.?\s*sc\.?\b|\bbachelor\s+of\s+science\b",

        "M.Sc":
            r"\bm\.?\s*sc\.?\b|\bmaster\s+of\s+science\b",

        "B.Com":
            r"\bb\.?\s*com\.?\b|\bbachelor\s+of\s+commerce\b",

        "M.Com":
            r"\bm\.?\s*com\.?\b|\bmaster\s+of\s+commerce\b",

        "BA":
            r"\bb\.?\s*a\.?\b|\bbachelor\s+of\s+arts\b",

        "MA":
            r"\bm\.?\s*a\.?\b|\bmaster\s+of\s+arts\b",

        "B.Ed":
            r"\bb\.?\s*ed\.?\b|\bbachelor\s+of\s+education\b",

        "M.Ed":
            r"\bm\.?\s*ed\.?\b|\bmaster\s+of\s+education\b",

        "PhD":
            r"\bph\.?\s*d\.?\b|\bdoctor\s+of\s+philosophy\b",

        "Diploma":
            r"\bdiploma\b"
    }

    found_degrees = []

    for degree, pattern in degree_patterns.items():

        if re.search(pattern, education_lower):
            found_degrees.append(degree)

    return found_degrees

# ============================================================
# RESUME STRENGTHS
# ============================================================

def generate_resume_strengths(resume_data, required_skills, matched_skills, job_role):
    strengths = []

    resume_skills = resume_data.get("skills") or []
    experience = resume_data.get("experience") or []
    projects = resume_data.get("projects") or []
    degrees = resume_data.get("degrees") or []

    # --------------------------------------------------------
    # SKILL STRENGTH
    # --------------------------------------------------------

    if len(matched_skills) >= 5:
        strengths.append(
            f"Strong skill alignment with the {job_role} role, "
            f"with {len(matched_skills)} relevant skills matching job requirements."
        )

    elif len(matched_skills) >= 2:
        strengths.append(
            f"Your resume contains several skills relevant to the "
            f"{job_role} role."
        )

    # --------------------------------------------------------
    # SKILL DIVERSITY
    # --------------------------------------------------------

    if len(resume_skills) >= 8:
        strengths.append(
            f"Good technical skill coverage with {len(resume_skills)} "
            f"skills detected in the resume."
        )

    # --------------------------------------------------------
    # PROJECT STRENGTH
    # --------------------------------------------------------

    if len(projects) >= 2:
        strengths.append(
            f"Good project exposure with {len(projects)} projects "
            f"demonstrating practical experience."
        )

    elif len(projects) == 1:
        strengths.append(
            "The resume includes a practical project that can "
            "demonstrate applied skills."
        )

    # --------------------------------------------------------
    # EXPERIENCE STRENGTH
    # --------------------------------------------------------

    if experience:
        if isinstance(experience, list) and len(experience) >= 1:
            strengths.append(
                "The resume includes practical work experience "
                "that can support the targeted role."
            )
        elif isinstance(experience, dict) and experience:
            strengths.append(
                "The resume contains professional experience "
                "relevant for career development."
            )

    # --------------------------------------------------------
    # EDUCATION
    # --------------------------------------------------------

    if degrees:
        strengths.append(
            f"Educational background detected: "
            f"{', '.join(degrees)}."
        )

    # --------------------------------------------------------
    # FALLBACK
    # --------------------------------------------------------

    if not strengths:
        strengths.append(
            "Your resume provides a starting foundation for the "
            f"{job_role} role."
        )

    return strengths


# ============================================================
# CAREER RECOMMENDATIONS
# ============================================================

def generate_career_recommendations(
    resume_data,
    missing_skills,
    matched_skills,
    job_role
):
    recommendations = []

    resume_skills = resume_data.get("skills") or []
    projects = resume_data.get("projects") or []
    experience = resume_data.get("experience") or []

    # --------------------------------------------------------
    # SKILL DEVELOPMENT
    # --------------------------------------------------------

    if missing_skills:
        top_missing = missing_skills[:5]

        recommendations.append({
            "title": "Develop Missing Skills",
            "description": (
                f"For the {job_role} role, consider developing these "
                f"job-relevant skills: {', '.join(top_missing)}."
            )
        })

    # --------------------------------------------------------
    # PROJECT RECOMMENDATION
    # --------------------------------------------------------

    if len(projects) < 2:
        recommendations.append({
            "title": "Build More Role-Relevant Projects",
            "description": (
                f"Add practical projects specifically related to "
                f"{job_role} to demonstrate applied knowledge."
            )
        })

    # --------------------------------------------------------
    # SKILL DEPTH
    # --------------------------------------------------------

    if len(resume_skills) < 8:
        recommendations.append({
            "title": "Expand Your Skill Set",
            "description": (
                f"Consider adding more relevant skills and tools "
                f"used in {job_role} job postings."
            )
        })

    # --------------------------------------------------------
    # EXPERIENCE
    # --------------------------------------------------------

    if not experience:
        recommendations.append({
            "title": "Gain Practical Experience",
            "description": (
                "Consider internships, freelance work, academic "
                "projects, or real-world projects to strengthen "
                "practical experience."
            )
        })

    # --------------------------------------------------------
    # MATCHED SKILLS
    # --------------------------------------------------------

    if matched_skills:
        recommendations.append({
            "title": "Highlight Your Relevant Skills",
            "description": (
                f"Your resume already contains {len(matched_skills)} "
                f"skills relevant to the target role. Make these "
                "skills clearly visible in your resume and projects."
            )
        })

    # --------------------------------------------------------
    # FALLBACK
    # --------------------------------------------------------

    if not recommendations:
        recommendations.append({
            "title": "Continue Building Role-Relevant Experience",
            "description": (
                f"Continue strengthening your experience and "
                f"projects around the {job_role} career path."
            )
        })

    return recommendations


# ============================================================
# MAIN ANALYSIS FUNCTION
# ============================================================

def analyze_resume(pdf_path, job_role):

    # ========================================================
    # RESUME EXTRACTION
    # ========================================================

    text = extract_text_from_pdf(pdf_path)

    project_lines = extract_projects(text)
    project_details = extract_project_details(project_lines)

    name = extract_name(text)
    email = extract_email(text)
    phone = extract_phone(text)

    skills = extract_skills(text)
    education = extract_education(text)

    language = extract_languages(text)
    availability = extract_availability(text)
    notice_period = extract_notice_period(text)
    relocation = extract_relocation(text)
    work_mode = extract_work_mode(text)

    experience = extract_experience(text)

    experience_dates = extract_experience_dates(
        experience
    )

    job_details = extract_job_details(
        experience
    )

    additional_information = {

        "languages": language,

        "availability": availability,

        "notice_period": notice_period,

        "relocation": relocation,

        "work_mode": work_mode
    }

    degrees = detect_degree(education)

    resume_data = {

        "name": name,

        "email": email,

        "phone": phone,

        "skills": skills,

        "education": education,

        "degrees": degrees,

        "additional_information":
            additional_information,

        "experience": experience,

        "experience_dates":
            experience_dates,

        "job_details":
            job_details,

        "projects":
            project_details
    }


    # ========================================================
    # VALIDATION
    # ========================================================

    missing_fields = validate_resume_data(
        resume_data
    )

    missing_fields = validate_resume(
        resume_data
    )


    # ========================================================
    # JOB SEARCH
    # ========================================================

    job_results = get_job_results(
        job_role
    )

    job_results = remove_duplicate_jobs(
        job_results
    )


    # ========================================================
    # JOB DESCRIPTION
    # ========================================================

    job_description = get_combined_job_description(
        job_results
    )


    # ========================================================
    # JOB SKILL EXTRACTION
    # ========================================================

    jd_data = parse_job_description(
        job_description,
        master_skills
    )


    # ========================================================
    # SKILL FREQUENCY
    # ========================================================

    skill_frequency = get_job_skill_frequency(
        job_results,
        master_skills
    )


    # ========================================================
    # SKILL CATEGORIES
    # ========================================================

    skill_categories = categorize_skills(
        skill_frequency,
        len(job_results)
    )


    # ========================================================
    # REQUIRED SKILLS
    # ========================================================

    required_skills = []

    total_jobs = len(job_results)

    if total_jobs > 0:
        for skill, frequency in skill_frequency.items():
            if frequency >= (total_jobs * 0.2):
                required_skills.append(skill)

    required_skills.sort(
        key=lambda skill: skill_frequency[skill],
        reverse=True
)


    # ========================================================
    # SKILL MATCHING
    # ========================================================

    match_result = match_skills(
        resume_data["skills"],
        required_skills
    )


    # ========================================================
    # CORE SKILL MATCHING
    # ========================================================

    core_match_result = match_core_skills(
        resume_data["skills"],
        skill_categories["core_skills"]
    )
    # ============================================================
    # RESUME STRENGTHS & CAREER RECOMMENDATIONS
    # ============================================================

    resume_strengths = generate_resume_strengths(
        resume_data,
        required_skills,
        match_result["matched_skills"],
        job_role
    )

    career_recommendations = generate_career_recommendations(
        resume_data,
        match_result["missing_skills"],
        match_result["matched_skills"],
        job_role
    )


    # ========================================================
    # FINAL REPORT
    # ========================================================

    final_report = {

        "resume": resume_data,

        "missing_fields":
            missing_fields,

        "job_role":
            job_role,

        "job_sources": [

            {
                "title":
                    result.get(
                        "title",
                        ""
                    ),

                "url":
                    result.get(
                        "url",
                        ""
                    )
            }

            for result in job_results
        ],

        "required_skills":
            required_skills,

        "skill_frequency":
            skill_frequency,

        "core_skills":
            skill_categories[
                "core_skills"
            ],

        "additional_skills":
            skill_categories[
                "additional_skills"
            ],

        "matched_skills":
            match_result[
                "matched_skills"
            ],

        "missing_skills":
            match_result[
                "missing_skills"
            ],

        "overall_match_score":
            match_result[
                "match_score"
            ],

        "matched_core_skills":
            core_match_result[
                "matched_core_skills"
            ],

        "missing_core_skills":
            core_match_result[
                "missing_core_skills"
            ],

        "core_match_score":
            core_match_result[
                "core_match_score"
            ],
            
        "resume_strengths":
            resume_strengths,

        "career_recommendations":
            career_recommendations
    }


    return final_report