
import re



STOP_WORDS = {
    "and", "or", "the", "with", "for", "in", "of", "to",
    "a", "an", "on", "using", "based", "experience",
    "knowledge", "skills", "skill", "tools", "technology",
    "technologies", "strong", "good", "excellent",
    "working", "ability", "responsible", "management",
    "team", "communication"
}



KNOWN_SKILLS = {
    
    "python", "java", "javascript", "typescript", "c", "c++", "c#",
    "php", "ruby", "go", "golang", "rust", "kotlin", "swift",
    "r programming", "matlab", "scala", "perl",

    # Web
    "html", "css", "react", "react.js", "angular", "vue", "node.js",
    "node", "express.js", "next.js", "bootstrap", "tailwind",

    
    "machine learning", "deep learning", "artificial intelligence",
    "data science", "data analysis", "nlp", "computer vision",
    "generative ai", "llm", "large language models",
    "natural language processing",

    
    "pandas", "numpy", "matplotlib", "seaborn", "scikit-learn",
    "tensorflow", "pytorch", "keras", "opencv",

    
    "sql", "mysql", "postgresql", "mongodb", "oracle", "sqlite",
    "redis", "cassandra", "firebase",

    
    "aws", "azure", "google cloud", "gcp", "docker", "kubernetes",
    "jenkins", "terraform", "git", "github", "gitlab",

    
    "cybersecurity", "ethical hacking", "penetration testing",
    "network security", "digital forensics", "wireshark",
    "nmap", "linux", "kali linux", "burp suite", "metasploit",
    "incident response", "siem",

    
    "power bi", "tableau", "excel", "power query", "power pivot",
    "looker", "qlik sense", "data visualization",
    "data cleaning", "data preprocessing", "feature engineering",
    "exploratory data analysis", "eda", "statistics",

    
    "linear regression", "logistic regression", "decision tree",
    "random forest", "xgboost", "svm", "support vector machine",
    "knn", "clustering", "k-means", "neural networks",

    
    "fastapi", "flask", "django", "spring boot", "rest api",
    "restful api", "api development",

    
    "git", "github", "version control", "software development",
    "object oriented programming", "oop", "data structures",
    "algorithms"
}


def clean_text(text):
    
    text = text.replace("\u2022", " ")
    text = text.replace("", " ")
    text = text.replace("\n", " ")

    
    text = re.sub(r"\s+", " ", text)

    return text.strip()


def extract_skills(text):
    

    text = clean_text(text)
    text_lower = text.lower()

    found_skills = []

    
    sorted_skills = sorted(
        KNOWN_SKILLS,
        key=len,
        reverse=True
    )

    for skill in sorted_skills:

        skill_lower = skill.lower()

       
        escaped_skill = re.escape(skill_lower)

        
        pattern = r"(?<!\w)" + escaped_skill + r"(?!\w)"

        if re.search(pattern, text_lower):
            found_skills.append(skill)

    return sorted(set(found_skills))

