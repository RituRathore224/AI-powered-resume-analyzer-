
print("\nDegrees:")