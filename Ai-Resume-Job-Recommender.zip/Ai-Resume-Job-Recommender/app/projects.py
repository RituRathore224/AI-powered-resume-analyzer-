import re


def extract_projects(text):

    lines = text.splitlines()

    project_start_keywords = [
        "projects",
        "academic projects",
        "personal projects",
        "key projects",
        "major projects",
        "project experience"
    ]

    section_stop_keywords = [
        "experience",
        "work experience",
        "professional experience",
        "education",
        "skills",
        "technical skills",
        "certifications",
        "achievements",
        "languages",
        "interests",
        "hobbies",
        "summary",
        "objective",
        "contact"
    ]

    project_lines = []

    inside_projects = False

    for line in lines:

        line = line.strip()

        if not line:
            continue

        clean_line = line.lower().strip(":- ")

        
        if clean_line in project_start_keywords:

            inside_projects = True
            continue

        
        if inside_projects and clean_line in section_stop_keywords:

            break

        
        if inside_projects:

            project_lines.append(line)

    return project_lines

def extract_project_details(project_lines):

    projects = []

    current_project = None

    for line in project_lines:

        line = line.strip()

        if not line:
            continue

        
        line = line.replace("\uf0b7", "").strip()

        
        if "|" in line:

            project_name, technologies = line.split("|", 1)

            project_name = project_name.strip()
            technologies = technologies.strip()

            technology_list = [
                tech.strip()
                for tech in technologies.split(",")
                if tech.strip()
            ]

            if current_project is not None:
                projects.append(current_project)

            current_project = {
                "project_name": project_name,
                "technologies": technology_list,
                "description": []
            }

        else:

            if current_project is not None:
                current_project["description"].append(line)

    
    if current_project is not None:
        projects.append(current_project)

    return projects