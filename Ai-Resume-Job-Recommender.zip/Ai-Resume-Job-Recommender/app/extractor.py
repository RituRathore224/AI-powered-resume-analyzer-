import re

def extract_email(text):
    pattern = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b'
    match = re.search(pattern, text)
    if match:
        return match.group()

    return None

def extract_phone(text):
    pattern  = r'(?<!\d)(?:\+91[\s-]?)?[6-9]\d{4}[\s-]?\d{5}(?!\d)'
    match = re.search(pattern, text)
    if match:
        return match.group()

    return None

def extract_name(text):
    lines = text.splitlines()
    for line in lines:
        line = line.strip()
        if line and not any (char.isdigit() for char in line):
            if "@" not in line and len(line.split())>=2:
                return line
    return None
def extract_education(text):
    lines = text.splitlines()

    education_keywords = [
        "education",
        "academic qualification",
        "educational background",
        "qualifications"
    ]

    stop_keywords = [
        "skills",
        "technical skills",
        "experience",
        "work experience",
        "projects",
        "certifications",
        "achievements",
        "summary",
        "objective",
        "contact"
    ]

    education = []

    inside_education = False

    for line in lines:
        line = line.strip()

        if not line:
            continue

        line_lower = line.lower()

        
        if any(keyword in line_lower for keyword in education_keywords):
            inside_education = True
            continue

        
        if inside_education and any(
            keyword in line_lower for keyword in stop_keywords
        ):
            break

        
        if inside_education:
            education.append(line)

    return education